"""Init."""
__version__ = "0.1.0a3"
from .cmat2aset import cmat2aset

__all__ = ("cmat2aset",)
